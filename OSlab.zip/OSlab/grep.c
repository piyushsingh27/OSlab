#include<stdio.h>
#include<string.h>

int main()
{
    FILE *fptr;
    fptr = fopen("sample","w");
    
}